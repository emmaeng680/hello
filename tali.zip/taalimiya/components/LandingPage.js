import React from 'react'

export default function LandingPage(){
  return(
    <div className= "space-y-2 flex-1 flex text-center 
      flex-col justify-center items-center">
      <div>
      <p className="block font-medium text-2xl sm:text-4xl">
        La première platforme de
      </p>

      <p className="block font-medium text-2xl sm:text-4xl">
        tutorat en ligne du Maroc.
      </p>
      
      <p className=" font-light inline text-xs sm:text-sm"   >
        Apprenons ensemble! Votre tuteur en ligne chez Taalimiya.ma
      </p>
      </div>

      <div className="space-x-2">
        <button className="select-none px-2 py-1 border-2 border-white rounded-full">
         <p> Trouver un tuteur</p>
        </button>

        <button className="select-none px-2 py-1 border-2 border-white rounded-full"> 
         <p> Devenir tuteur </p>
        </button>

      </div>

    </div>
  )
}
