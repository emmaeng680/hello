self.__NEXT_FONT_MANIFEST={
  "pages": {},
  "app": {
    "/data/data/com.termux/files/home/taalimiya/node_modules/next/dist/build/webpack/loaders/css-loader/src/index.js??ruleSet[1].rules[1].oneOf[3].use[1]!/data/data/com.termux/files/home/taalimiya/node_modules/next/dist/build/webpack/loaders/next-font-loader/index.js??ruleSet[1].rules[1].oneOf[3].use[2]!/data/data/com.termux/files/home/taalimiya/node_modules/next/font/google/target.css?{\"arguments\":[{\"subsets\":[\"latin\"]}],\"import\":\"Inter\",\"path\":\"pages/index.js\",\"variableName\":\"inter\"}": [
      "static/media/2aaf0723e720e8b9-s.p.woff2"
    ]
  },
  "appUsingSizeAdjust": true,
  "pagesUsingSizeAdjust": false
}